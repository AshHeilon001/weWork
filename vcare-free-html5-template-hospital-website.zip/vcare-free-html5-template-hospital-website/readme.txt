Free Responsive HTML5 Bootstrap Template

vCare is a free HTML5 bootstrap template, specially desinged for any hospital website, doctor, dentist etc. This theme has a latest modern design built in HTML5 and CSS3 for multi-purpose use. Theme has an responsive design, easy to use on desktop and mobile phones compatible with multi browser.   

Key features
-------------
Twitter Bootstrap 3.3.1
Clean & Developer-friendly HTML5 and CSS3 code
100% Responsive Layout Design 
Multi-purpose theme
Google Fonts Support
Font Awesome 
Smooth Scrolling 
Fully Customizable
Contact Form

Credits :
-------
=> Design and developed: "WebThemez"  http://webthemez.com
=> Photos used in template: **Unsplash** - http://unsplash.com
=> For more free web themes: http://webthemez.com
=> Framework : http://getbootstrap.com
=> For more help: webthemez@gmail.com
=> Do not remove the back-link from site. If you want remove back-link please donate some bucks.

License :
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/

Note:
All images user here is for demo purpose only, we are not responsible for any copyrights.
